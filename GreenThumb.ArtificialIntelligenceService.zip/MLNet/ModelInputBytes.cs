﻿using Microsoft.ML.Data;

namespace GreenThumb.ArtificialIntelligenceService
{
    public class ModelInputBytes
    {
        [ColumnName(@"Label")]
        public string Label { get; set; }

        [ColumnName(@"Features")]
        public byte[] ImageBytes { get; set; }

    }
}
