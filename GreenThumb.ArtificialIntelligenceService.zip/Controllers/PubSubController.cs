using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Dapr.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using GreenThumb.Microservice.Core;
using Dapr;
using GreenThumb.ArtificialIntelligenceService.Events;

namespace GreenThumb.ArtificialIntelligenceService
{
    [ApiController]
    [Authorize(AuthenticationSchemes = "Internal")]
    [Route("[controller]")]
    public class PubSubController : BaseController<PubSubController>
    {
        private readonly ArtificialIntelligenceService _artificialIntelligenceService;

        public PubSubController(DaprClient daprClient, UserService userService,  ILogger<PubSubController> logger, ArtificialIntelligenceService artificialIntelligenceService) : base(daprClient, userService, logger)
        {
            this._artificialIntelligenceService = artificialIntelligenceService ?? throw new ArgumentNullException(nameof(ArtificialIntelligenceService));
        }

        [Topic("pubsub", "image_updated")]
        [HttpPost("imageupdated")]
        public async Task<ActionResult> ImageUpdated([FromBody] ImageUpdated imageUpdatedEvent)
        {
            try
            {
                if (imageUpdatedEvent != null)
                {
                    await _artificialIntelligenceService.EvaluateHealthinessAsync(imageUpdatedEvent);
                    return Ok();
                }
                else
                {
                    return Ok("The NewNotificationEvent cannot be null or empty.");
                }

            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                return Problem(e.Message);
            }
        }
    }
}
