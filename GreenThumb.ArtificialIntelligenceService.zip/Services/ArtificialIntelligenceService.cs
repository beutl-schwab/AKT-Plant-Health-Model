using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Dapr.Client;
using System.Text.Json;
using GreenThumb.ArtificialIntelligenceService.Models;
using GreenThumb_ArtificialIntelligenceService;
using static GreenThumb_ArtificialIntelligenceService.MLModel;
using Microsoft.ML;
using GreenThumb.ArtificialIntelligenceService.Events;
using System.Drawing;
using System.IO;
using System.Reflection;

namespace GreenThumb.ArtificialIntelligenceService
{
    public class ArtificialIntelligenceService
    {
        public const string StoreName = "artificialintelligencestore";
        public const string PubsubName = "pubsub";

        private readonly DaprClient daprClient;
        private readonly ILogger<ArtificialIntelligenceService> logger;


        public ArtificialIntelligenceService(ILogger<ArtificialIntelligenceService> logger, DaprClient daprClient)
        {
            this.daprClient = daprClient ?? throw new ArgumentNullException(nameof(daprClient));
            this.logger = logger;
        }

        protected async Task<Dapr.StateEntry<PlantHealth>> GetPlantHealthAsync(string imageId)
        {
            return await this.daprClient.GetStateEntryAsync<PlantHealth>(StoreName, imageId);
        }

        public string SaveImage(ImageUpdated inputImage)
        {
            byte[] bytes = Convert.FromBase64String(inputImage.Content);

            var dir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            var path = Path.Combine(dir, "images/" + inputImage.ImageId + ".jpg");

            var imagesDir = Path.Combine(dir, "images");
            if (!Directory.Exists(imagesDir))
            {
                Directory.CreateDirectory(imagesDir);
            }

            File.WriteAllBytes(path, bytes);
            return path;
        }

        public async Task EvaluateHealthinessAsync(ImageUpdated imageUpdatedEvent)
        {
            // load image from imageservice

            if(imageUpdatedEvent != null && imageUpdatedEvent.Content.Any())
            {
                //save image locally
                string localImageUrl = SaveImage(imageUpdatedEvent);

                var predictionInput = new MLModel.ModelInput()
                {
                    ImageSource = localImageUrl
                };

                //Load model and predict output
                var result = MLModel.Predict(predictionInput);
                var score = result.Score[0];
                Console.WriteLine(score);

                await this.daprClient.SaveStateAsync(StoreName, imageUpdatedEvent.ImageId.ToString(), new PlantHealth()
                {
                    ImageId = imageUpdatedEvent.ImageId,
                    Score = score
                });
            }
        }
    }
}
