﻿using System;

namespace GreenThumb.ArtificialIntelligenceService.Models
{
    public class PlantHealth
    {
        public string ImageId { get; set; }

        public float Score { get; set; }
    }
}
