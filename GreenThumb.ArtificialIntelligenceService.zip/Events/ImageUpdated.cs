﻿using System;

namespace GreenThumb.ArtificialIntelligenceService.Events
{
    public class ImageUpdated
    {
        public string ImageId { get; set; }

        public string ContentType { get; set; }

        public string Content { get; set; }
    }
}
